package ca.sheridancollege.kumar319.service;

import ca.sheridancollege.kumar319.beans.enumeration.Status;
import ca.sheridancollege.kumar319.dto.service.OrderProductServiceModel;
import ca.sheridancollege.kumar319.dto.service.OrderServiceModel;
import ca.sheridancollege.kumar319.dto.service.ProductServiceModel;
import ca.sheridancollege.kumar319.dto.service.UserServiceModel;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;


@RunWith(SpringRunner.class)
@SpringBootTest
public class OrderServiceImplTests {

    @Autowired
    private OrderService orderService;

    @Test
    public void createOrder() {
        OrderServiceModel orderServiceModel = new OrderServiceModel();
        UserServiceModel userServiceModel = new UserServiceModel();
        userServiceModel.setId("f72a0e16-77bf-4a95-b0d2-1ab43d68646as");
        orderServiceModel.setCustomer(userServiceModel);
        List<OrderProductServiceModel> orderProductServiceModels = new ArrayList<>();
        OrderProductServiceModel orderProductServiceModel = new OrderProductServiceModel();
        ProductServiceModel product = new ProductServiceModel();
        orderProductServiceModel.setProduct(product);
        orderProductServiceModel.setPrice(BigDecimal.valueOf(120));
        orderProductServiceModels.add(orderProductServiceModel);
        List<OrderProductServiceModel> orderProductViewModels = new ArrayList<>();
        orderServiceModel.setProducts(orderProductViewModels);
        orderServiceModel.setShippingAddress("Boston, USA");
        orderServiceModel.setStatus(Status.Pending);
        orderServiceModel.setIssuedOn(LocalDateTime.now());
        orderServiceModel.setStatusDate(LocalDateTime.now());
        orderServiceModel.setTotalPrice(BigDecimal.valueOf(520));
        orderService.createOrder(orderServiceModel);
    }

    @Test
    public void findAllOrders() {
        List<OrderServiceModel> orderServiceModels = new ArrayList<>();
        System.out.println("Order list size: " + orderServiceModels.size());
    }

}