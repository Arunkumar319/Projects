package ca.sheridancollege.kumar319.repository;

import ca.sheridancollege.kumar319.beans.Category;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import static org.junit.Assert.assertEquals;

@RunWith(SpringRunner.class)
@SpringBootTest
public class CategoryRepoTest {

    @Autowired
    private CategoryRepository categoryRepository;

    @Test
    public void getUserNameTest() {
        String categoryName =  "Frozen";
        Category category = categoryRepository.getByCategoryName(categoryName);
        assertEquals(categoryName, category.getName());
    }

}
