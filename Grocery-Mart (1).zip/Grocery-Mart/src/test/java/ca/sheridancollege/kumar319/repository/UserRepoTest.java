package ca.sheridancollege.kumar319.repository;

import ca.sheridancollege.kumar319.beans.User;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import static org.junit.Assert.assertEquals;

@RunWith(SpringRunner.class)
@SpringBootTest
public class UserRepoTest {

    @Autowired
    private UserRepository userRepository;

    @Test
    public void getUserNameTest() {
        String username =  "abesa";
        User user = userRepository.getUserByUsername(username);
        assertEquals(username, user.getUsername());
    }
}
