package ca.sheridancollege.kumar319.service;

import ca.sheridancollege.kumar319.dto.service.CategoryServiceModel;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
public class CategoryServiceImplTests {


    @Autowired
    private CategoryService categoryService;

    @Test
    public void addCategory() {
        CategoryServiceModel category = new CategoryServiceModel();
        category.setName("Electronics");
        CategoryServiceModel saveCategory = categoryService.addCategory(category);
        System.out.println(saveCategory.getId());
    }

    @Test
    public void findAllCategories() {
        System.out.println(categoryService.findAllCategories());
    }

    @Test
    public void findCategoryById() {
        String catId = "dc93559f-a3ae-4df8-842d-5440446123ee";
        CategoryServiceModel category = categoryService.findCategoryById(catId);
        System.out.println(category);
    }

}