package ca.sheridancollege.kumar319.beans.enumeration;

public enum Status {
    
    Pending, Shipped, Delivered, Acquired;
}
