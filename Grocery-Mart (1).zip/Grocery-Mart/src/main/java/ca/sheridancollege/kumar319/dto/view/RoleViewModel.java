package ca.sheridancollege.kumar319.dto.view;

public class RoleViewModel {

    private String authority;

    public RoleViewModel() {
    }

    public String getAuthority() {
        return this.authority;
    }

    public void setAuthority(String authority) {
        this.authority = authority;
    }
}
