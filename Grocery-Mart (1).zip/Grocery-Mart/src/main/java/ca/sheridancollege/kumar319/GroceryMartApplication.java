package ca.sheridancollege.kumar319;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@EnableScheduling
public class GroceryMartApplication {

    public static void main(String[] args) {
        SpringApplication.run(GroceryMartApplication.class, args);
    }
}
